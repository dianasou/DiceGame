/* 
Rules:
On your turn, you roll six dice. 
Points are earned every time you roll a 1, 5, or three of a kind. 

If none of the dice rolled earned points, that's a Farkle! 
Your turn is over and you earn no points.

If you roll at least one scoring die, you can either bank your point total and pass your turn, 
or you can risk these points by putting aside the dice you’ve scored (at least one) 
and continuing to roll the remaining dice. The remaining dice may earn you additional points, 
but if you Farkle, you lose everything you’ve earned during your turn. 

Scoring is based only on the dice in each roll. 
You cannot earn points by combining dice from different rolls. 
You can continue rolling the dice until you either Pass or Farkle. 

For example, if a player rolls 2-4-5-5-5-6, they can choose to do any of the following:

Score a single 5 for 50 points and risk their points by rolling the remaining 5 dice.
Score the set of 5’s for 500 points and risk their points by rolling the remaining 3 dice.
Score the set of 5’s for 500 points and end their turn, banking those points.

In the first scenario, the player rolls five dice in their second throw. 
If they were to roll 2-3-4-5-5 in this throw, 
they can not combine these 5’s with the 5 rolled in the first throw. 
The player would only have the option to score these two 5’s individually for 100 points.

If the game is played by multiple players, 
then each player takes their turn in order until one player has 10,000 points at the end of their turn. 
Each player then has one more chance to score points, 
and whoever has the most points at the end of that round wins.

It’s completely up to you how you decide to portray gameplay and scoring. 
Be creative, and be sure to make a note of any assumptions or important decisions that you make along the way. 
We don’t expect you to complete this entire project in 3 hours, 
so part of the challenge is seeing how you prioritize the work.
*/

let diceArr = [];

function initializeDice(){
	for(i = 0; i < 6; i++){
		diceArr[i] = {};
		diceArr[i].value = i + 1;
		diceArr[i].clicked = 0;
	}
}

// rolling dice values
function rollDice(){
	for(let i = 0; i < 6; i++){
		if(diceArr[i].clicked === 0){
			diceArr[i].value = Math.floor((Math.random() * 6) + 1);
		}
	}
	console.log(diceArr);
	updateDiceImg();
}

// updating images of dice given values of rollDice
function updateDiceImg(){
	let diceImage;
	for(let i = 0; i < 6; i++){
		diceImage = "images/" + diceArr[i].value + ".png";
		diceArr[i].id = "die" + diceArr[i].value;
		// change image
		document.getElementById(diceArr[i].id).setAttribute("src", diceImage);
		document.getElementById(diceArr[i].id).src=diceImage;
	
	}
	score();
}

function diceClick(img){
	let i = img.getAttribute("data-number");

	img.classList.toggle("transparent");
	if(diceArr[i].clicked === 0){
		diceArr[i].clicked == 1;
	}
	else{
		diceArr[i].clicked == 0;
	}
}

// update points
function score() {
	let theScore = 0;
	for(let i = 0; i < 6; i++){
		//check if roll is 1 or 5
		if (diceArr[i].value === 1 || diceArr[i].value === 5) {
			theScore += 50;
			document.querySelector("p").innerHTML = theScore;
		} else {
			document.querySelector("p").innerHTML = theScore;
		}
	}
}